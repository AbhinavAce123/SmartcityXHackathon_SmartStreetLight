from flask import Flask, request, jsonify, render_template
from datetime import datetime

app = Flask(__name__)

# In-memory message storage (clear on server restart)
messages = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/messages', methods=['GET'])
def get_messages():
    return jsonify(messages)

@app.route('/api/post', methods=['POST'])
def post_message():
    data = request.get_json()
    msg = data.get('message', '').strip()
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if msg:
        messages.append({'time': ts, 'message': msg})
        # Keep last 100 messages
        if len(messages) > 100:
            messages.pop(0)
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
